packages = c("shiny", "shinyWidgets", "bslib", "readxl")
sapply(1:length(packages), FUN = function(i)  {ifelse(require(packages[i]), install.packages(packages[i]), libary(packages[i]))} )
